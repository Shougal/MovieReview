<?php
class Config {
    public static $db = [
        "host" => "localhost",
        "port" => 5432,
        "user" => "xdq9qa",
        "pass" => "HHPgkuQpS6Zd",
        "database" => "xdq9qa"
    ];
    /*
        public static $db = [
        "host" => "db",
        "port" => 5432,
        "user" => "localuser",
        "pass" => "cs4640LocalUser!",
        "database" => "example"
    ];
    */
    public static $private_api_key = "dd9f9aae";
}